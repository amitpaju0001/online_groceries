
import 'package:curved_labeled_navigation_bar/curved_navigation_bar.dart';
import 'package:curved_labeled_navigation_bar/curved_navigation_bar_item.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:online_groceries/explore_screen.dart';
import 'package:online_groceries/home_screen.dart';
import 'package:online_groceries/my_cart_screen.dart'; // Ensure this import is correct

class StartingHomeScreen extends StatefulWidget {
  const StartingHomeScreen({super.key});

  @override
  State<StartingHomeScreen> createState() => _StartingHomeScreenState();
}

class _StartingHomeScreenState extends State<StartingHomeScreen> {
  List<Widget> screens = [
   HomeScreen(),
    ExploreScreen(),
    MyCartScreen(),
  ];
  int currentTab = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: currentTab,
        children: screens,
      ),
      bottomNavigationBar: CurvedNavigationBar(
        backgroundColor: Colors.green,
        items: [
          CurvedNavigationBarItem(
            child: Icon(Icons.shopify),
            label: 'Shop',
          ),
          CurvedNavigationBarItem(
            child: Icon(Icons.manage_search_sharp),
            label: 'Explore',
          ),
          CurvedNavigationBarItem(
            child: Icon(Icons.shopping_cart),
            label: 'Cart',
          ),
          CurvedNavigationBarItem(
            child: Icon(CupertinoIcons.heart),
            label: 'Favorite',
          ),
          CurvedNavigationBarItem(
            child: Icon(Icons.perm_identity),
            label: 'Account',
          ),
        ],
        index: currentTab,
        onTap: (int index) {
          setState(() {
            currentTab = index;
          });
        },
      ),
    );
  }
}
