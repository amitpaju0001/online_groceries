
import 'package:flutter/material.dart';
import 'package:online_groceries/cart_items_class.dart';

class MyCartScreen extends StatefulWidget {
  const MyCartScreen({super.key});

  @override
  State<MyCartScreen> createState() => _MyCartScreenState();
}

class _MyCartScreenState extends State<MyCartScreen> {
  final List<CartItems> items = [
    CartItems(image: 'https://purepng.com/public/uploads/large/purepng.com-bell-peppersvegetables-chilli-bell-pepper-pepper-capsicum-sweet-pepper-red-chili-941524722426zkz8k.png' ,name: 'Bell Pepper Red', quantity: '1kg', price: 4.99),
    CartItems(image: 'https://purepng.com/public/uploads/large/purepng.com-eggseggseggshellegg-whiteegg-yolk-1411527408744w05gf.png', name: 'Egg Chicken Red', quantity: '4pcs', price: 1.99),
    CartItems(image: 'https://purepng.com/public/uploads/large/purepng.com-mario-kart-bananasbananafruityellowyummytasty-331522344013npr3i.png', name: 'Organic Bananas', quantity: '1.2kg', price: 3.99),
    CartItems(image: 'https://purepng.com/public/uploads/large/purepng.com-gingergingerhotasian-plantpreserved-in-syrup-1701527257185h2sxx.png',name: 'Ginger', quantity: '250gm', price: 2.99),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('My Cart'),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: items.length,
              itemBuilder: (context, index) {
                final item = items[index];
                return ListTile(
                    leading: Image.network(
                      item.image,
                      width: 40,
                      height: 40,
                    ),
                  title: Text(item.name),
                  subtitle: Text(item.quantity),
                  trailing: Text('${item.price.toStringAsFixed(2)}'),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
