
import 'package:carousel_slider/carousel_slider.dart';
import 'package:curved_labeled_navigation_bar/curved_navigation_bar.dart';
import 'package:curved_labeled_navigation_bar/curved_navigation_bar_item.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:online_groceries/explore_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<String> imageList = [
    'https://tse4.mm.bing.net/th?id=OIP.HhpbROR9SKghDdbkFTCSMwHaEK&pid=Api&P=0&h=180',
    'https://tse3.mm.bing.net/th?id=OIP.3VO0wAU4GQhiL33bPNSUHQHaFj&pid=Api&P=0&h=180',
    'https://tse4.mm.bing.net/th?id=OIP.ccp5biEbFB097dxLMMFUvQHaHW&pid=Api&P=0&h=180',
  ];



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Image.network(
          'https://cdn-icons-png.flaticon.com/128/3480/3480410.png',
          height: 20,
          width: 20,
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              ListTile(
              contentPadding: EdgeInsets.only(left: 86),
                leading: Icon(Icons.location_on),
                title: Text(
                  'Dhaka, Banassre',
                  style: TextStyle(fontWeight: FontWeight.bold, color: Colors.grey),
                ),
              ),
              TextField(
                decoration: InputDecoration(
                    focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide: BorderSide(color: Colors.blueAccent)),
                    border:
                        OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                    prefixIcon: Icon(Icons.search),
                    hintText: 'Search Store'),
              ),
              CarouselSlider.builder(
                itemCount: imageList.length,
                itemBuilder: (context, index, pageIndex) {
                  String imageUrl = imageList[index];
                  return Image.network(imageUrl);
                },
                options: CarouselOptions(
                  height: MediaQuery.of(context).size.height * 0.2,
                  autoPlay: true,
                  enlargeCenterPage: true,
                  viewportFraction: 0.9,
                ),
              ),
              ListTile(
                title: Text('Exclusive Offer'),
                trailing: Text('See all',style: TextStyle(
                  color: Colors.green
                ),),
              ),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    Container(
                      width: MediaQuery.of(context).size.width*0.4,
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey.shade300),
                      borderRadius: BorderRadius.circular(16),
                    ),
                      child: Column(
                        children: [
                          Image.network('https://tse4.mm.bing.net/th?id=OIP.TNxxAzdHi3duqlnyyH7pygHaFB&pid=Api&P=0&h=180',width: 72,height: 80,),
                          ListTile(
                            title: Text(' Bananas'),
                            subtitle: Text(
                              '7pcs, Priceg',
                            ),
                          ),
                          ListTile(
                            title: Text("\$4.99"),
                            trailing: Icon(Icons.add_box_rounded,color: Colors.green,),
                          )
                        ],
                      ),
                    ),
                    SizedBox(width: 16,),
                    Container(
                      width: MediaQuery.of(context).size.width*0.4,
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey.shade300),
                      borderRadius: BorderRadius.circular(16),
                    ),
                      child: Column(
                        children: [
                          Image.network('https://www.pngkey.com/png/full/932-9328480_apples-png-image-red-apple-fruit.png',width: 72,height: 80,),
                          ListTile(
                            title: Text('Red Apple'),
                            subtitle: Text(
                              '1Kg, Priceg',
                            ),
                          ),
                          ListTile(
                            title: Text("\$4.99"),
                            trailing: Icon(Icons.add_box_rounded,color: Colors.green,),
                          )
                        ],
                      ),
                    ),
                    SizedBox(width: 16,),
                    Container(
                      width: MediaQuery.of(context).size.width*0.4,
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey.shade300),
                      borderRadius: BorderRadius.circular(16),
                    ),
                      child: Column(
                        children: [
                          Image.network('http://pluspng.com/img-png/fruits-png-hd-fruit-free-png-image-png-image-2500.png',width: 72,height: 80,),
                          ListTile(
                            title: Text('Oranges'),
                            subtitle: Text(
                              '1Kg, Priceg',
                            ),
                          ),
                          ListTile(
                            title: Text("\$4.99"),
                            trailing: Icon(Icons.add_box_rounded,color: Colors.green,),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              ListTile(
                title: Text('Best Selling'),
                trailing: Text('See all',style: TextStyle(
                  color: Colors.green
                ),),
              ),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    Container(
                      width: MediaQuery.of(context).size.width*0.4,
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey.shade300),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Column(
                        children: [
                          Image.network('https://tse1.mm.bing.net/th?id=OIP.Q6fVGDegCWnklPPJdch2aAHaE8&pid=Api&P=0&h=180',width: 72,height: 80,),
                          ListTile(
                            title: Text(' Red chilli'),
                            subtitle: Text(
                              '1kg, Priceg',
                            ),
                          ),
                          ListTile(
                            title: Text("\$4.99"),
                            trailing: Icon(Icons.add_box_rounded,color: Colors.green,),
                          )
                        ],
                      ),
                    ),
                    SizedBox(width: 16,),
                    Container(
                      width: MediaQuery.of(context).size.width*0.4,
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey.shade300),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Column(
                        children: [
                          Image.network('https://tse3.mm.bing.net/th?id=OIP.o20vnrAxGIoqUGRB7MgGuAHaHa&pid=Api&P=0&h=180',width: 72,height: 80,),
                          ListTile(
                            title: Text('Ginger'),
                            subtitle: Text(
                              '500g, Priceg',
                            ),
                          ),
                          ListTile(
                            title: Text("\$4.99"),
                            trailing: Icon(Icons.add_box_rounded,color: Colors.green,),
                          )
                        ],
                      ),
                    ),
                    SizedBox(width: 16,),
                    Container(
                      width: MediaQuery.of(context).size.width*0.4,
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey.shade300),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Column(
                        children: [
                          Image.network('https://tse1.mm.bing.net/th?id=OIP.LRGQpr4trlD_k9iMQ_vzcQHaFt&pid=Api&P=0&h=180',width: 72,height: 80,),
                          ListTile(
                            title: Text('Tomato'),
                            subtitle: Text(
                              '1Kg, Priceg',
                            ),
                          ),
                          ListTile(
                            title: Text("\$2.99"),
                            trailing: Icon(Icons.add_box_rounded,color: Colors.green,),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              ListTile(
                title: Text('Groceries'),
                trailing: Text('See all',style: TextStyle(color: Colors.green),),
              ),

              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                    child: Row(
                      children: [
                        Container(
                          height: MediaQuery.of(context).size.height*0.1,
                          width: MediaQuery.of(context).size.width*0.6,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(16),
                            color: Colors.orange.shade50
                          ),
                          child: Row(
                            children: [
                              Image.network('https://www.aywadeal.com/wp-content/uploads/2018/12/pulses-png-8.png'),
                            Text('Pulses'),
                            ],
                          ),
                        ),
                        SizedBox(width: 16,),
                        Container(
                          height: MediaQuery.of(context).size.height*0.1,
                          width: MediaQuery.of(context).size.width*0.6,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(16),
                              color: Colors.green.shade50
                          ),
                          child: Row(
                            children: [
                              Image.network('https://www.pngarts.com/files/3/White-Rice-PNG-Transparent-Image.png'),
                              Text('Rice'),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    Container(
                      width: MediaQuery.of(context).size.width*0.4,
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey.shade300),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Column(
                        children: [
                          Image.network('https://tse3.mm.bing.net/th?id=OIP.Vfg5BeyQzrr0R0ne2tRo9AHaFj&pid=Api&P=0&h=180',width: 72,height: 80,),
                          ListTile(
                            title: Text(' Beef bone'),
                            subtitle: Text(
                              '1kg, Priceg',
                            ),
                          ),
                          ListTile(
                            title: Text("\$4.99"),
                            trailing: Icon(Icons.add_box_rounded,color: Colors.green,),
                          )
                        ],
                      ),
                    ),
                    SizedBox(width: 16,),
                    Container(
                      width: MediaQuery.of(context).size.width*0.4,
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey.shade300),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Column(
                        children: [
                          Image.network('https://tse3.explicit.bing.net/th?id=OIP.SXnBFF8Xxt0io5D1FZU1DAHaE2&pid=Api&P=0&h=180',width: 72,height: 80,),
                          ListTile(
                            title: Text('Broiler chicken'),
                            subtitle: Text(
                              '1kg, Priceg',
                            ),
                          ),
                          ListTile(
                            title: Text("\$4.99"),
                            trailing: Icon(Icons.add_box_rounded,color: Colors.green,),
                          )
                        ],
                      ),
                    ),
                    SizedBox(width: 16,),
                    Container(
                      width: MediaQuery.of(context).size.width*0.4,
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey.shade300),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Column(
                        children: [
                          Image.network('https://tse2.mm.bing.net/th?id=OIP.-1gdA7eGB3Fr6BDFcGZj2gHaG0&pid=Api&P=0&h=180',width: 72,height: 80,),
                          ListTile(
                            title: Text('Eggs'),
                            subtitle: Text(
                              '12pc, Priceg',
                            ),
                          ),
                          ListTile(
                            title: Text("\$2.99"),
                            trailing: Icon(Icons.add_box_rounded,color: Colors.green,),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
